"""Reproduce the frozen Census graph inputs from official population-center files."""
from pathlib import Path
import argparse,csv,json,math
import numpy as np

def prepare(root,output=None):
 root=Path(root);manifest=json.load(open(root/'冻结Census30.json'));graphs=manifest['graphs'];package=root.parent/'instances/Census';assert len(graphs)==10 and len(manifest['cases'])==30
 if output:Path(output).mkdir(parents=True,exist_ok=True)
 for e in graphs:
  source=root/'original_data'/e['source_url'].split('/')[-1];rows=[x for x in csv.DictReader(source.open(encoding='utf-8-sig')) if int(x['POPULATION'])>0];rows.sort(key=lambda x:(x['STATEFP'],x['COUNTYFP'],x['TRACTCE']));n=len(rows);assert n==e['n'];w=[int(x['POPULATION']) for x in rows];assert sum(w)==e['profit_sum'];lat=np.radians([float(x['LATITUDE']) for x in rows]);lon=np.radians([float(x['LONGITUDE']) for x in rows]);limit=math.sin(e['service_radius_km']/(2*6371.0088))**2;edges=[]
  for start in range(0,n,128):
   stop=min(start+128,n);h=np.sin((lat[start:stop,None]-lat[None,:])/2)**2+np.cos(lat[start:stop,None])*np.cos(lat[None,:])*np.sin((lon[start:stop,None]-lon[None,:])/2)**2;u,v=np.nonzero((h<=limit)&(np.arange(start,stop)[:,None]<np.arange(n)[None,:]));edges.extend(zip((u+start).tolist(),v.tolist()))
  edges.sort();assert len(edges)==e['m'];payload=str(n)+'\n'+''.join(f'{i} {x}\n' for i,x in enumerate(w))+''.join(f'{u} {v}\n' for u,v in edges);assert (package/Path(e['file']).name).read_text()==payload,e['id']
  if output:(Path(output)/Path(e['file']).name).write_text(payload)
  print('verified',e['id'],flush=True)
 print('Verified 10 Census graphs and 30 frozen threshold cases.')
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--root',type=Path,default=Path(__file__).resolve().parent);p.add_argument('--output-dir',type=Path);a=p.parse_args();prepare(a.root,a.output_dir)
