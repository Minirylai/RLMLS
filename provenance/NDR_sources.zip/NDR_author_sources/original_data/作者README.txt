1. Type I and Type II Graphs:

	The first two lines contain information about the number of nodes in the graph.
	The next N lines provide the coordinates of the N nodes (one coordinate per line).
	The following N lines give the weights of the N nodes (one weight per line).
	The remaining lines represent the adjacency matrix:
		A value of 1 indicates an edge between two nodes.
		A value of 0 indicates no edge between them.



2. UDG (Unit Disk Graph) Format:
	The first line contains the number of nodes, say N.
	The next N lines give the weights of the N nodes.
	The remaining lines list the edges as pairs of node indices (edge endpoints), one edge per line.



3. NDR Graphs:
	The first two lines should be ignored (they may contain the number of nodes and edges).
	From the third line onward, each line represents an edge as a pair of node indices.
	Some lines may include additional information after the edge endpoints; this extra data should be ignored.
	The node weights are provided separately in a file named node_weights.txt.

